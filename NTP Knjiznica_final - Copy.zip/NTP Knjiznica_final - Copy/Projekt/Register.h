//---------------------------------------------------------------------------

#ifndef RegisterH
#define RegisterH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <Vcl.Dialogs.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Imaging.pngimage.hpp>
#include "uTPLb_BaseNonVisualComponent.hpp"
#include "uTPLb_Codec.hpp"
#include "uTPLb_CryptographicLibrary.hpp"
#include <System.SysUtils.hpp>
#include "uTPLb_Signatory.hpp"
#include <map>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TEdit *FirstName;
	TEdit *LastName;
	TEdit *User;
	TEdit *Pass;
	TLabel *Name;
	TLabel *Surname;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label1;
	TButton *Register;
	TButton *Button1;
	TADOTable *ADOTable1;
	TDataSource *DataSource1;
	TComboBox *ComboBox1;
	TCodec *Codec1;
	TCryptographicLibrary *CryptographicLibrary1;
	TButton *Home;
	void __fastcall RegisterClick(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall ComboBox1Change(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall HomeClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
 std::map<String, std::map<String, String>> translation;
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
