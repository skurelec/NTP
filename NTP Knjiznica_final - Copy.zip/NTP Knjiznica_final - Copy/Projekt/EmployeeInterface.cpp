//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "EmployeeInterface.h"
#include "EmergencyServices.h"
#include <IdHashSHA.hpp>
#include <jpeg.hpp>
#include <pngimage.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma resource "*.dfm"
#include <IniFiles.hpp>
#include "Homepage.h"
#include "EmployeeAddBooks.h"
TForm3 *Form3;
//---------------------------------------------------------------------------
		  void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm3::TForm3(TComponent* Owner)
	: TForm(Owner)
{
translation["Label1"] =  {
	{
		{"US", "First name"},
		{"HR", "Ime"}
	}
	};
translation["Label2"] =  {
	{
		{"US", "Last name"},
		{"HR", "Prezime"}
	}
	};
translation["Label3"] =  {
	{
		{"US", "Username"},
		{"HR", "Korisnicko ime"}
	}
	};
translation["Label4"] =  {
	{
		{"US", "Password"},
		{"HR", "�ifra"}
	}
	};
translation["Button8"] =  {
	{
		{"US", "Add"},
		{"HR", "Dodaj"}
	}
	};
translation["Button7"] =  {
	{
		{"US", "Update"},
		{"HR", "A�uriraj"}
	}
	};
translation["Button1"] =  {
	{
		{"US", "Delete"},
		{"HR", "Izbri�i"}
	}
	};
translation["Label5"] =  {
	{
		{"US", "Type"},
		{"HR", "Tip"}
	}
	};
translation["Label6"] =  {
	{
		{"US", "Phone number"},
		{"HR", "Broj mobitela"}
	}
	};
translation["Button6"] =  {
	{
		{"US", "Update Selected"},
		{"HR", "A�uriraj odabrano"}
	}
	};
translation["Button3"] =  {
	{
		{"US", "Add"},
		{"HR", "Dodaj"}
	}
	};
translation["Button4"] =  {
	{
		{"US", "Delete Selected"},
		{"HR", "Izbri�i odabrano"}
	}
	};
translation["Button5"] =  {
	{
		{"US", "Edit selected"},
		{"HR", "Izmjeni odabrano"}
	}
	};
translation["Button2"] =  {
	{
		{"US", "Show Emergency services"},
		{"HR", "Prika�i Hitne Kontakte"}
	}
	};
    translation["Home"] =  {
	{
		{"US", "Home"},
		{"HR", "Pocetna"}
	}
	};
translation["Books"] =  {
	{
		{"US", "Books"},
		{"HR", "Knjige"}
	}
	};
translation["Button9"] =  {
	{
		{"US", "Show Name"},
		{"HR", "Prika�i Ime"}
	}
	};
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button2Click(TObject *Sender)
{
_di_IXMLemergencyServicesType EmergencyServices = GetemergencyServices(XMLDocument1);
ListView1->Items->Clear();
for(int i = 0; i < EmergencyServices->Count;i++){
ListView1->Items->Add();
ListView1->Items->Item[i]->Caption = EmergencyServices->service[i]->type;
ListView1->Items->Item[i]->SubItems->Add(EmergencyServices->service[i]->phoneNumber) ;
}


}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button3Click(TObject *Sender)
{
_di_IXMLemergencyServicesType EmergencyServices = GetemergencyServices(XMLDocument1);
_di_IXMLserviceType Service = EmergencyServices->Add();

Service->type = Edit1->Text;
Service->phoneNumber = Edit2->Text;

XMLDocument1->SaveToFile(XMLDocument1->FileName);




}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button4Click(TObject *Sender)
{
_di_IXMLemergencyServicesType EmergencyServices = GetemergencyServices(XMLDocument1);

EmergencyServices->Delete(ListView1->ItemIndex);

XMLDocument1->SaveToFile(XMLDocument1->FileName);

}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button5Click(TObject *Sender)
{
_di_IXMLemergencyServicesType EmergencyServices = GetemergencyServices(XMLDocument1);
_di_IXMLserviceType Service = EmergencyServices->service[ListView1->ItemIndex];

Edit1->Text = Service->type;
Edit2->Text = Service->phoneNumber;
XMLDocument1->SaveToFile(XMLDocument1->FileName);



}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button6Click(TObject *Sender)
{
_di_IXMLemergencyServicesType EmergencyServices = GetemergencyServices(XMLDocument1);
_di_IXMLserviceType Service = EmergencyServices->service[ListView1->ItemIndex];

Service->type = Edit1->Text;
Service->phoneNumber = Edit2->Text;
XMLDocument1->SaveToFile(XMLDocument1->FileName);
}
//---------------------------------------------------------------------------



void __fastcall TForm3::Button8Click(TObject *Sender)
{
String Sol;
if (Password->Text.Length() < 6) {
	Sol = "TOP";
} else {
    Sol = "BOT";
}

String PossiblePapars[] = {"papar1", "papar2", "papar3"};
String Papar = PossiblePapars[rand() % (sizeof(PossiblePapars) / sizeof(PossiblePapars[0]))];
TIdHashSHA1* sha1 = new TIdHashSHA1;
String hashedPassword = sha1->HashStringAsHex(Password->Text + Sol + Papar);

Codec1->Password = "Crypt";
String CodedFirstName;
Codec1->EncryptString(FirstName->Text, CodedFirstName, TEncoding::UTF8);


ADOTable2->Insert();
ADOTable2->FieldByName("First Name")->AsString = CodedFirstName;
ADOTable2->FieldByName("Last Name")->AsString = LastName->Text;
ADOTable2->FieldByName("Username")->AsString = Username->Text;
ADOTable2->FieldByName("Password")->AsString = hashedPassword;
ADOTable2->Post();

}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button7Click(TObject *Sender)
{
ADOTable2->Edit();
ADOTable2->FieldByName("First Name")->AsString = FirstName->Text;
ADOTable2->FieldByName("Last Name")->AsString = LastName->Text;
ADOTable2->FieldByName("Username")->AsString = Username->Text;

}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button1Click(TObject *Sender)
{
ADOTable2->Delete();
}
//---------------------------------------------------------------------------



void __fastcall TForm3::ComboBox1Change(TObject *Sender)
{
translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------


void __fastcall TForm3::Button9Click(TObject *Sender)
{
Codec1->Password = "Crypt";
String Decoded;
String Encoded = ADOTable2->FieldByName("First Name")->AsString;
Codec1->DecryptString(Decoded,Encoded , TEncoding::UTF8);
DecodedName->Text = Decoded;
}
//---------------------------------------------------------------------------

void __fastcall TForm3::FormCreate(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "Language.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm3::HomeClick(TObject *Sender)
{
Form6->Show();
this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::BooksClick(TObject *Sender)
{
Form10->Show();
}
//---------------------------------------------------------------------------

