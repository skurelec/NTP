//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "LoginEmployee.h"
#include <map>
#include <IniFiles.hpp>
#include "Homepage.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#include "EmployeeInterface.h"

TForm8 *Form8;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm8::TForm8(TComponent* Owner)
	: TForm(Owner)
{
    translation["Label1"] =  {
	{
		{"US", "Username"},
		{"HR", "Korisnicko ime"}
	}
	};
	translation["Label2"] =  {
	{
		{"US", "Password"},
		{"HR", "�ifra"}
	}
	};
	translation["Login"] =  {
	{
		{"US", "Login"},
		{"HR", "Prijavi se"}
	}
	};
    translation["Home"] =  {
	{
		{"US", "Home"},
		{"HR", "Pocetna"}
	}
	};

}
//---------------------------------------------------------------------------
void __fastcall TForm8::LoginClick(TObject *Sender)
{
IdTCPClient2->Connect();
	 IdTCPClient2->Socket->WriteLn(Username->Text);
	 IdTCPClient2->Socket->WriteLn(Password->Text);

	 int odgovor = IdTCPClient2->Socket->ReadInt32();
	 IdTCPClient2->Disconnect();

     if(odgovor == 1){
	Form3->Show();
    this->Hide();
    }

}
//---------------------------------------------------------------------------

void __fastcall TForm8::ComboBox1Change(TObject *Sender)
{
	translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm8::FormCreate(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "Language.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm8::HomeClick(TObject *Sender)
{
Form6->Show();
this->Close();
}
//---------------------------------------------------------------------------

