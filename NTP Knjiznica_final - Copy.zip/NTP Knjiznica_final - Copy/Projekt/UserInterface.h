//---------------------------------------------------------------------------

#ifndef UserInterfaceH
#define UserInterfaceH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <Vcl.DBCtrls.hpp>
#include <Vcl.DBGrids.hpp>
#include <Vcl.Grids.hpp>
#include <Vcl.Mask.hpp>
#include <Vcl.Dialogs.hpp>
#include "uTPLb_BaseNonVisualComponent.hpp"
#include "uTPLb_Codec.hpp"
#include "uTPLb_CryptographicLibrary.hpp"
#include "uTPLb_Signatory.hpp"
#include <System.SysUtils.hpp>
#include <map>
//---------------------------------------------------------------------------
class TForm5 : public TForm
{
__published:	// IDE-managed Components
	TADOTable *ADOTable1;
	TDataSource *DataSource1;
	TDBGrid *DBGrid1;
	TButton *AditionalData;
	TWideStringField *ADOTable1ISBN;
	TWideStringField *ADOTable1Title;
	TWideStringField *ADOTable1Author;
	TLabel *Label1;
	TDBEdit *DBEdit1;
	TLabel *Label2;
	TDBEdit *DBEdit2;
	TLabel *Label3;
	TDBEdit *DBEdit3;
	TButton *Filter;
	TEdit *ISBNFilter;
	TButton *Clear;
	TButton *Lookup;
	TEdit *LookupText;
	TLabel *Label4;
	TLabel *Label5;
	TComboBox *ComboBox1;
	TButton *Button1;
	TLabel *Label7;
	TDBImage *DBImage1;
	TBlobField *ADOTable1BookType;
	TComboBox *ComboBox2;
	TButton *Button2;
	TButton *Home;
	TButton *Button3;
	TSignatory *Signatory1;
	TCodec *Codec1;
	TCryptographicLibrary *CryptographicLibrary1;
	void __fastcall AditionalDataClick(TObject *Sender);
	void __fastcall FilterClick(TObject *Sender);
	void __fastcall ClearClick(TObject *Sender);
	void __fastcall LookupClick(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall ComboBox2Change(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall HomeClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
std::map<String, std::map<String, String>> translation;
	__fastcall TForm5(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm5 *Form5;
//---------------------------------------------------------------------------
#endif
