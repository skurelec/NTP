﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "EmployeeAddBooks.h"
#include <jpeg.hpp>
#include <pngimage.hpp>
#include <System.JSON.hpp>
#include <memory>
#include <System.JSON.readers.hpp>
#include <map>
#include "LibraryBranches.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma link "uTPLb_Signatory"
#pragma resource "*.dfm"
#include <fstream>
#include <IniFiles.hpp>
#include "Homepage.h"
#include "UserInterface.h"
#include "EmployeeInterface.h"
TForm10 *Form10;
//---------------------------------------------------------------------------
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String, String>>& translation){
	for(int i= 0; i < Form->ComponentCount; i++)
		for(auto it_ComponentName = translation.begin(); it_ComponentName != translation.end(); it_ComponentName++)
			if(Form->Components[i]->Name == it_ComponentName->first)
				for(auto it_Language = it_ComponentName->second.begin(); it_Language != it_ComponentName->second.end(); it_Language++)
					if(it_Language->first == Language)
						if(IsPublishedProp(Form->Components[i], "Caption"))
							SetPropValue(Form->Components[i], "Caption", it_Language->second);
}
__fastcall TForm10::TForm10(TComponent* Owner)
	: TForm(Owner)
{
DBImage1->DoubleBuffered = true;
	translation["Label1"] =  {
	{
		{"US", "ISBN"},
		{"HR", "ISBN"}
	}
	};
	translation["Label2"] =  {
	{
		{"US", "Title"},
		{"HR", "Naslov"}
	}
	};
	translation["Label3"] =  {
	{
		{"US", "Author"},
		{"HR", "Autor"}
	}
	};
	translation["Button1"] =  {
	{
		{"US", "Insert"},
		{"HR", "Dodaj"}
	}
	};
	translation["Button2"] =  {
	{
		{"US", "Update"},
		{"HR", "Ažuriraj"}
	}
	};
	translation["Button3"] =  {
	{
		{"US", "Delete"},
		{"HR", "Izbriši"}
	}
	};
	translation["Button4"] =  {
	{
		{"US", "Add Book Type"},
		{"HR", "Dodaj tip knjige"}
	}
	};
	translation["Button11"] =  {
	{
		{"US", "Sign"},
		{"HR", "Potpisi"}
	}
	};
	translation["Button9"] =  {
	{
		{"US", "Upload library branches"},
		{"HR", "Objavi podružnice"}
	}
	};
	translation["Button10"] =  {
	{
		{"US", "Get signature keys"},
		{"HR", "Ucitaj kljuceve"}
	}
	};
	translation["Label8"] =  {
	{
		{"US", "ID"},
		{"HR", "ID"}
	}
	};
	translation["Label4"] =  {
	{
		{"US", "Name"},
		{"HR", "Ime"}
	}
	};
	translation["Label5"] =  {
	{
		{"US", "Location"},
		{"HR", "Lokacija"}
	}
	};
	translation["Label6"] =  {
	{
		{"US", "Contact"},
		{"HR", "Kontakt"}
	}
	};
	translation["Label7"] =  {
	{
		{"US", "Website"},
		{"HR", "Stranica"}
	}
	};
	translation["Button6"] =  {
	{
		{"US", "Add JSON"},
		{"HR", "Dodaj JSON"}
	}
	};
	translation["Button5"] =  {
	{
		{"US", "Load JSON"},
		{"HR", "Učitaj JSON"}
	}
	};
	translation["Button8"] =  {
	{
		{"US", "Delete JSON"},
		{"HR", "Izbriši JSON"}
	}
	};
	translation["Button7"] =  {
	{
		{"US", "Save JSON"},
		{"HR", "Spremi JSON"}
	}
	};
    translation["Home"] =  {
	{
		{"US", "Home"},
		{"HR", "Početna"}
	}
	};
translation["Interface"] =  {
	{
		{"US", "Interface"},
		{"HR", "Sučelje"}
	}
	};

}
//---------------------------------------------------------------------------
void __fastcall TForm10::Button1Click(TObject *Sender)
{
ADOTable1->Insert();
ADOTable1->FieldByName("ISBN")->AsString = ISBN->Text;
ADOTable1->FieldByName("Title")->AsString = Title->Text;
ADOTable1->FieldByName("Author")->AsString = Author->Text;
ADOTable1->Post();
}
//---------------------------------------------------------------------------
void __fastcall TForm10::Button2Click(TObject *Sender)
{
ADOTable1->Edit();
ADOTable1->FieldByName("ISBN")->AsString = ISBN->Text;
ADOTable1->FieldByName("Title")->AsString = Title->Text;
ADOTable1->FieldByName("Author")->AsString = Author->Text;
}
//---------------------------------------------------------------------------
void __fastcall TForm10::Button3Click(TObject *Sender)
{
ADOTable1->Delete();
}
//---------------------------------------------------------------------------
void __fastcall TForm10::Button4Click(TObject *Sender)
{
if(OpenDialog1->Execute()){
ADOTable1->Edit();
static_cast <TBlobField*> (ADOTable1->FieldByName("Book Type"))->LoadFromFile(OpenDialog1->FileName);
ADOTable1->Post();
}
}
//---------------------------------------------------------------------------


void __fastcall TForm10::Button5Click(TObject *Sender)
{
std::unique_ptr<TStringStream> jsonStream(new TStringStream);
jsonStream->LoadFromFile("Providers.json");
UnicodeString jsonDoc = jsonStream->DataString;
TJSONObject* Providers =(TJSONObject*)TJSONObject::ParseJSONValue(jsonDoc);
TJSONArray* providers = (TJSONArray*)TJSONObject::ParseJSONValue(
 Providers->GetValue("providers")->ToString());
UnicodeString provider;
for(int i = 0; i < providers->Count; i++){
String id = providers->Items[i]->GetValue<UnicodeString>("id");
String name = providers->Items[i]->GetValue<UnicodeString>("name");
String location = providers->Items[i]->GetValue<UnicodeString>("location");
String contact = providers->Items[i]->GetValue<UnicodeString>("contact");
String website = providers->Items[i]->GetValue<UnicodeString>("website");

ListView1->Items->Add();
ListView1->Items->Item[i]->Caption = id;
ListView1->Items->Item[i]->SubItems->Add(name);
ListView1->Items->Item[i]->SubItems->Add(location);
ListView1->Items->Item[i]->SubItems->Add(contact);
ListView1->Items->Item[i]->SubItems->Add(website);
}

}
//---------------------------------------------------------------------------

void __fastcall TForm10::Button6Click(TObject *Sender)
{
ListView1->Items->Add();
int lastindex = ListView1->Items->Count-1;
ListView1->Items->Item[lastindex]->Caption = Id->Text;
ListView1->Items->Item[lastindex]->SubItems->Add(Name->Text);
ListView1->Items->Item[lastindex]->SubItems->Add(Location->Text);
ListView1->Items->Item[lastindex]->SubItems->Add(Contact->Text);
ListView1->Items->Item[lastindex]->SubItems->Add(Website->Text);

}
//---------------------------------------------------------------------------

void __fastcall TForm10::Button7Click(TObject *Sender)
{
    String JSONDocument;
    JSONDocument = "{\n";
    JSONDocument += "\"providers\": [\n";
    for (int i = 0; i < ListView1->Items->Count; i++) {
        JSONDocument +=
            "    {\n"
            "        \"id\":\"" + ListView1->Items->Item[i]->Caption + "\",\n" +
            "        \"name\":\"" + ListView1->Items->Item[i]->SubItems->Strings[0] + "\",\n" +
            "        \"location\":\"" + ListView1->Items->Item[i]->SubItems->Strings[1] + "\",\n" +
            "        \"contact\":\"" + ListView1->Items->Item[i]->SubItems->Strings[2] + "\",\n" +
            "        \"website\":\"" + ListView1->Items->Item[i]->SubItems->Strings[3] + "\"\n" +
            "    }";
        JSONDocument += (i + 1 != ListView1->Items->Count) ? ",\n" : "\n";
    }
    JSONDocument += "]\n";
    JSONDocument += "}";

    std::unique_ptr<TStringStream> ss(new TStringStream(JSONDocument));
    ss->SaveToFile("Providers.json");
}


//---------------------------------------------------------------------------

void __fastcall TForm10::Button8Click(TObject *Sender)
{
ListView1->DeleteSelected();
}
//---------------------------------------------------------------------------

















void __fastcall TForm10::ComboBox1Change(TObject *Sender)
{
 translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------




void __fastcall TForm10::Button10Click(TObject *Sender)
{
std::unique_ptr<TMemoryStream> privateKey (new TMemoryStream);
std::unique_ptr<TMemoryStream> publicKey (new TMemoryStream);

if(Signatory1->GenerateKeys()){
Signatory1->StoreKeysToStream(privateKey.get(),
TKeyStoragePartSet() << partPrivate);

Signatory1->StoreKeysToStream(publicKey.get(),
TKeyStoragePartSet() << partPublic);

privateKey->SaveToFile("Private.bin");
publicKey->SaveToFile("Public.bin");
}
}
//---------------------------------------------------------------------------

void __fastcall TForm10::Button11Click(TObject *Sender)
{
std::unique_ptr<TMemoryStream> document(new TMemoryStream);
document ->LoadFromFile("poslovnice.dat");

std::unique_ptr<TMemoryStream> privateKey(new TMemoryStream);
privateKey->LoadFromFile("Private.bin");
Signatory1->LoadKeysFromStream(privateKey.get(),TKeyStoragePartSet()<< partPrivate);

std::unique_ptr<TMemoryStream> signature(new TMemoryStream);
Signatory1->Sign(document.get(),signature.get());
signature->SaveToFile("signature.bin");

ShowMessage("Document signed");

}
//---------------------------------------------------------------------------


void __fastcall TForm10::Button9Click(TObject *Sender)
{
Form12->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm10::FormCreate(TObject *Sender)
{
TIniFile *ini;
ini = new TIniFile(GetCurrentDir() + "Language.ini");
ComboBox1->Text = ini->ReadString("LANGUAGE INI","ComboBox1->Text","");
delete ini;

translateForm(this, ComboBox1->Text, translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm10::HomeClick(TObject *Sender)
{
Form6->Show();
this->Close();
}
//---------------------------------------------------------------------------


void __fastcall TForm10::InterfaceClick(TObject *Sender)
{
Form3->Show();
this->Close();
}
//---------------------------------------------------------------------------

