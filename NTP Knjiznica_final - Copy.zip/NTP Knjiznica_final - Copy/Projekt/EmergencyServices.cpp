
// ************************************************************************************************ //
//                                                                                                
//                                        XML Data Binding                                        
//                                                                                                
//         Generated on: 26/08/2023 12:31:31                                                      
//       Generated from: C:\Users\stjep\Desktop\Projektni zadatak\Projekt\EmergencyServices.xml   
//   Settings stored in: C:\Users\stjep\Desktop\Projektni zadatak\Projekt\EmergencyServices.xdb   
//                                                                                                
// ************************************************************************************************ //

#include <System.hpp>
#pragma hdrstop

#include "EmergencyServices.h"


// Global Functions 

_di_IXMLemergencyServicesType __fastcall GetemergencyServices(Xml::Xmlintf::_di_IXMLDocument Doc)
{
  return (_di_IXMLemergencyServicesType) Doc->GetDocBinding("emergencyServices", __classid(TXMLemergencyServicesType), TargetNamespace);
};

_di_IXMLemergencyServicesType __fastcall GetemergencyServices(Xml::Xmldoc::TXMLDocument *Doc)
{
  Xml::Xmlintf::_di_IXMLDocument DocIntf;
  Doc->GetInterface(DocIntf);
  return GetemergencyServices(DocIntf);
};

_di_IXMLemergencyServicesType __fastcall LoademergencyServices(const System::UnicodeString& FileName)
{
  return (_di_IXMLemergencyServicesType) Xml::Xmldoc::LoadXMLDocument(FileName)->GetDocBinding("emergencyServices", __classid(TXMLemergencyServicesType), TargetNamespace);
};

_di_IXMLemergencyServicesType __fastcall  NewemergencyServices()
{
  return (_di_IXMLemergencyServicesType) Xml::Xmldoc::NewXMLDocument()->GetDocBinding("emergencyServices", __classid(TXMLemergencyServicesType), TargetNamespace);
};

// TXMLemergencyServicesType 

void __fastcall TXMLemergencyServicesType::AfterConstruction(void)
{
  RegisterChildNode(System::UnicodeString("service"), __classid(TXMLserviceType));
  ItemTag = "service";
  ItemInterface = __uuidof(IXMLserviceType);
  Xml::Xmldoc::TXMLNodeCollection::AfterConstruction();
};

_di_IXMLserviceType __fastcall TXMLemergencyServicesType::Get_service(int Index)
{
  return (_di_IXMLserviceType) List->Nodes[Index];
};

_di_IXMLserviceType __fastcall TXMLemergencyServicesType::Add()
{
  return (_di_IXMLserviceType) AddItem(-1);
};

_di_IXMLserviceType __fastcall TXMLemergencyServicesType::Insert(const int Index)
{
  return (_di_IXMLserviceType) AddItem(Index);
};

// TXMLserviceType 

System::UnicodeString __fastcall TXMLserviceType::Get_type()
{
  return GetChildNodes()->Nodes[System::UnicodeString("type")]->Text;
};

void __fastcall TXMLserviceType::Set_type(System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("type")]->NodeValue = Value;
};

System::UnicodeString __fastcall TXMLserviceType::Get_phoneNumber()
{
  return GetChildNodes()->Nodes[System::UnicodeString("phoneNumber")]->Text;
};

void __fastcall TXMLserviceType::Set_phoneNumber(System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("phoneNumber")]->NodeValue = Value;
};
