﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "mydllform.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#include <fstream>
TFDLLForm *FDLLForm;
//---------------------------------------------------------------------------
class Binary {
public:
	wchar_t _naziv[10];
	float _inacica;

	Binary() {
		wcsncpy(_naziv, L"Binary", 10);
		_inacica = 1.0;
	}
};


class PoslovnicaKnjiznice {
public:
	wchar_t _naziv[50], _adresa[100], _grad[50], _telefon[25],_brojPoslovnice[10];

	PoslovnicaKnjiznice() {}
	PoslovnicaKnjiznice(wchar_t* naziv, wchar_t* adresa, wchar_t* brojPoslovnice, wchar_t* grad, wchar_t* telefon) {
		wcsncpy(_naziv, naziv, 50);
		wcsncpy(_adresa, adresa, 100);
		wcsncpy(_brojPoslovnice, brojPoslovnice, 10);
		wcsncpy(_grad, grad, 50);
		wcsncpy(_telefon, telefon, 25);
	}
};




__fastcall TFDLLForm::TFDLLForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFDLLForm::FormCreate(TObject *Sender)
{
	 ListView2->Items->Clear();
	 std::unique_ptr<TMemoryStream> PosloniceStream(new TMemoryStream);
	 PosloniceStream->LoadFromFile("poslovnice.dat");

	 Binary Header;
	 PosloniceStream->Read(&Header, sizeof(Binary));

	 if(String(Header._naziv) != "Binary" || Header._inacica != 1.0){
		ShowMessage("Wrong Format!");
        return;
     }

	 PoslovnicaKnjiznice tmp;
	 int PoslovniceCount = (PosloniceStream->Size - sizeof(Header)) / sizeof(PoslovnicaKnjiznice);
	 for(int i = 0; i < PoslovniceCount; i++) {
		PosloniceStream->Read(&tmp, sizeof(PoslovnicaKnjiznice));

		ListView2->Items->Add();
		ListView2->Items->Item[i]->Caption = String(tmp._naziv);
		ListView2->Items->Item[i]->SubItems->Add(tmp._adresa);
		ListView2->Items->Item[i]->SubItems->Add(tmp._brojPoslovnice);
		ListView2->Items->Item[i]->SubItems->Add(tmp._grad);
        ListView2->Items->Item[i]->SubItems->Add(tmp._telefon);
	 }
}
//---------------------------------------------------------------------------

