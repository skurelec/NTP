//---------------------------------------------------------------------------

#ifndef mydllformH
#define mydllformH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
//---------------------------------------------------------------------------
#ifdef EXPORTS
  #define DLL_EXPORT __declspec(dllexport)
#else
  #define DLL_EXPORT __declspec(dllimport)
#endif
class DLL_EXPORT TFDLLForm : public TForm
{
__published:	// IDE-managed Components
	TListView *ListView2;
	void __fastcall FormCreate(TObject *Sender);
private:	// User declarations

public:		// User declarations
	__fastcall TFDLLForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern DLL_EXPORT TFDLLForm *FDLLForm;
//---------------------------------------------------------------------------
#endif
